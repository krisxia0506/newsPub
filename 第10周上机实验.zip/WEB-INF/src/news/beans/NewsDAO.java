package news.beans;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 * Created on 2022-10-27 10:30
 *
 * @author Xia Jiayi
 */
public class NewsDAO {
    /**
     * 查看所有新闻
     * @return ArrayList<News>
     */
    public ArrayList<News> getAllNews() {
        News news = null;
        ArrayList<News> newsList = new ArrayList<News>();
        Connection conn = null;
        ResultSet rs = null;
        Statement stmt = null;
        try {
            conn = DBGet.getConnection();
            stmt = conn.createStatement();
            String sql = "select * from news";
            rs = stmt.executeQuery(sql);
            while (rs.next()) {
                news = new News();
                news.setId(rs.getInt("id"));
                news.setTitle(rs.getString("title"));
                news.setContent(rs.getString("content"));
                news.setAuthor(rs.getString("author"));
                news.setPubtime(rs.getString("pubtime"));
                news.setKeyword(rs.getString("keyword"));
                news.setAcnumber(rs.getString("acnumber"));
                newsList.add(news);


            }

        } catch (SQLException e1) {
            System.out.println(e1);
        } finally {
            DBGet.closeConnection(conn);
        }
        return newsList;
    }
    /**
     * 插入一条新闻
     * @return boolean
     */
    public boolean insert (News news){
        boolean result = false;
        int n = 0;
        news.setPubtime(getNowStr());
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBGet.getConnection();
            String sql="insert into news(title,content,author,pubtime,keyword,newstype) value(?,?,?,?,?,?)";
            ps = conn.prepareStatement(sql);
            ps.setString(1,news.getTitle());
            ps.setString(2,news.getContent());
            ps.setString(3,news.getAuthor());
            ps.setString(4,news.getPubtime());
            ps.setString(5,news.getKeyword());
            ps.setString(6,news.getNewstype());
            n=ps.executeUpdate();
        }catch (SQLException e1){
            System.out.println(e1);
        }finally {
            DBGet.closeConnection(conn);
        }
        if (n>0){
            result = true;
        }
        return result;
    }
    /**
     * 以yyyy-MM-dd HH:mm:SS格式返回当前时间字符串
     * @return String
     * */
    public String getNowStr() {
        String resultStr = null;
        String pattern ="yyyy-MM-dd HH:mm:ss";
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        try {
            resultStr=sdf.format(date);
        }catch (Exception e){
            e.printStackTrace();
        }
        return resultStr;

    }
    /**
     * 根据ID查询指定新闻
     */
    public News getById(String id){
        News news = null;
        Connection conn = null;
        ResultSet rs = null;
        PreparedStatement ps =null;
        try {
            conn=DBGet.getConnection();
            String sql="select * from news where id=?";
            ps=conn.prepareStatement(sql);
            ps.setString(1,id);
            rs=ps.executeQuery();
            if (rs.next()){
                news = new News();
                news.setId(rs.getInt("id"));
                news.setTitle(rs.getString("title"));
                news.setContent(rs.getString("content"));
                news.setAuthor(rs.getString("author"));
                news.setPubtime(rs.getString("pubtime"));
                news.setKeyword(rs.getString("keyword"));
                news.setAcnumber(rs.getString("acnumber"));
                news.setNewstype(rs.getString("newstype"));

            }
        }catch (SQLException e1){
            System.out.println(e1);
        }finally {
            DBGet.closeConnection(conn);
        }
        return news;
    }

}
