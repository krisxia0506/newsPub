package news.servlet;

import news.beans.News;
import news.beans.NewsDAO;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Created on 2022-11-09 16:27
 *
 * @author Xia Jiayi
 */
public class NewsServlet extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ArrayList<News> newsList = new ArrayList<News>();
        NewsDAO newsDAO = new NewsDAO();

        String func = request.getParameter("action");
        if (func == null) {
            func = "";
        }
        if ("query".equals(func)) {
            String keyword = request.getParameter("keyword");

            newsList = newsDAO.getNewsByKeyword(keyword);
            request.setAttribute("newsList", newsList);
            request.getRequestDispatcher("listNews.jsp").forward(request, response);
        } else {
            newsList = newsDAO.getAllNews();

            request.setAttribute("newsList", newsList);
            request.getRequestDispatcher("listNews.jsp").forward(request, response);
        }

    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }

}
