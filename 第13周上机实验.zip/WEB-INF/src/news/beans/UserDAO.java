package news.beans;

import java.sql.*;

/**
 * Created on 2022-10-12 13:28
 * 6.2
 *
 * @author Xia Jiayi
 */
public class UserDAO {
    public boolean queryByNamePwd(String uName, String up) {
        boolean result = false;
        Connection conn = null;
        ResultSet rs = null;
        PreparedStatement ps = null;
        try {
            conn = DBGet.getConnection();
            String sql = "select * from user where username=? and password=?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, uName);
            ps.setString(2, up);
            rs = ps.executeQuery();
            if (rs != null && rs.next()) {
                result = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBGet.closeConnection(conn);
        }
        return result;
    }

    public boolean deleteById(String id) {
        boolean result = false;
        Connection conn = null;

        PreparedStatement ps = null;
        try {
            conn = DBGet.getConnection();
            String sql = "DELETE FROM user WHERE id = ?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, id);


            if (ps.executeUpdate() == 1) {
                result = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBGet.closeConnection(conn);
        }
        return result;
    }

    public boolean updataUserById(User user) {
        boolean result = false;
        Connection conn = null;

        PreparedStatement ps = null;
        try {
            conn = DBGet.getConnection();
            String sql = "UPDATE user SET username=?,password=?,gender=?,resume=? WHERE id=?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getPassword());
            ps.setString(3, user.getGender());
            ps.setString(4, user.getResume());
            ps.setInt(5, user.getId());


            if (ps.executeUpdate() == 1) {
                result = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBGet.closeConnection(conn);
        }
        return result;
    }

    public boolean insertUserById(User user) {
        boolean result = false;
        Connection conn = null;

        PreparedStatement ps = null;
        try {
            conn = DBGet.getConnection();
            String sql = "INSERT INTO user VALUES(null,?,?,?,?)";
            ps = conn.prepareStatement(sql);
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getPassword());
            ps.setString(3, user.getGender());
            ps.setString(4, user.getResume());


            if (ps.executeUpdate() == 1) {
                result = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBGet.closeConnection(conn);
        }
        return result;
    }


}
