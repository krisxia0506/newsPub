package news.beans;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 * Created on 2022-10-27 10:30
 *
 * @author Xia Jiayi
 */
public class NewsDAO {
    /**
     * 查看所有新闻
     *
     * @return ArrayList<News>
     */
    public ArrayList<News> getAllNews() {
        News news = null;
        ArrayList<News> newsList = new ArrayList<News>();
        Connection conn = null;
        ResultSet rs = null;
//        Statement stmt = null;
        try {
            conn = DBGet.getConnection();
            Statement stmt = conn.createStatement();
            String sql = "select * from news";
            rs = stmt.executeQuery(sql);
            while (rs.next()) {
                news = new News();
                news.setId(rs.getInt("id"));
                news.setTitle(rs.getString("title"));
                news.setContent(rs.getString("content"));
                news.setAuthor(rs.getString("author"));
                news.setPubtime(rs.getString("pubtime"));
                news.setKeyword(rs.getString("keyword"));
                news.setAcnumber(rs.getString("acnumber"));
                news.setNewstype(rs.getString("newstype"));
                newsList.add(news);


            }

        } catch (SQLException e1) {
            System.out.println(e1);
        } finally {
            DBGet.closeConnection(conn);
        }
        return newsList;
    }

    /**
     * 插入一条新闻
     *
     * @return boolean
     */
    public boolean insert(News news) {
        boolean result = false;
        int n = 0;
        news.setPubtime(getNowStr());
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBGet.getConnection();
            String sql = "insert into news(title,content,author,pubtime,keyword,newstype) value(?,?,?,?,?,?)";
            ps = conn.prepareStatement(sql);
            ps.setString(1, news.getTitle());
            ps.setString(2, news.getContent());
            ps.setString(3, news.getAuthor());
            ps.setString(4, news.getPubtime());
            ps.setString(5, news.getKeyword());
            ps.setString(6, news.getNewstype());
            n = ps.executeUpdate();
        } catch (SQLException e1) {
            System.out.println(e1);
        } finally {
            DBGet.closeConnection(conn);
        }
        if (n > 0) {
            result = true;
        }
        return result;
    }

    /**
     * 以yyyy-MM-dd HH:mm:SS格式返回当前时间字符串
     *
     * @return String
     */
    public String getNowStr() {
        String resultStr = null;
        String pattern = "yyyy-MM-dd HH:mm:ss";
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        try {
            resultStr = sdf.format(date);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return resultStr;

    }

    /**
     * 根据ID查询指定新闻
     */
    public News getById(String id) {
        News news = null;
        Connection conn = null;
        ResultSet rs = null;
        PreparedStatement ps = null;
        try {
            conn = DBGet.getConnection();
            String sql = "select * from news where id=?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            rs = ps.executeQuery();
            if (rs.next()) {
                news = new News();
                news.setId(rs.getInt("id"));
                news.setTitle(rs.getString("title"));
                news.setContent(rs.getString("content"));
                news.setAuthor(rs.getString("author"));
                news.setPubtime(rs.getString("pubtime"));
                news.setKeyword(rs.getString("keyword"));
                news.setAcnumber(rs.getString("acnumber"));
                news.setNewstype(rs.getString("newstype"));

            }
        } catch (SQLException e1) {
            System.out.println(e1);
        } finally {
            DBGet.closeConnection(conn);
        }
        return news;
    }

    /**
     * 增加访问量
     */
    public void increaseAc(String id) {
        boolean result = false;
        int n = 0;
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBGet.getConnection();
            String sql = "update news set acnumber = acnumber +1 where id=?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            n = ps.executeUpdate();
        } catch (SQLException e1) {
            System.out.println(e1);
        } finally {
            DBGet.closeConnection(conn);
        }
        if (n > 0) {
            result = true;
        }
    }

    /**
     * 相关新闻
     */
    public ArrayList<News> getRelate(String id) {
        News news = null;
        ArrayList<News> newsList = new ArrayList<News>();
        Connection conn = null;
        ResultSet rs = null;
        try {
            conn = DBGet.getConnection();
            String sql = "SELECT * from news where newstype=(select newstype from news where id=?) and id != ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            ps.setString(2, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                news = new News();
                news.setId(rs.getInt("id"));
                news.setTitle(rs.getString("title"));

                newsList.add(news);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            DBGet.closeConnection(conn);
        }
        return newsList;
    }

    /**
     * 修改新闻
     */
    public boolean modify(News news) {
        boolean result = false;
        int n = 0;
        Connection conn = null;
        String sql = null;
        PreparedStatement ps = null;
        try {
            conn = DBGet.getConnection();
            sql = "update news set title=?,content=?,author=?,pubtime=?,keyword=?,acnumber=?,newstype=? where id =?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, news.getTitle());
            ps.setString(2, news.getContent());
            ps.setString(3, news.getAuthor());
            ps.setString(4, news.getPubtime());
            ps.setString(5, news.getKeyword());
            ps.setString(6, news.getAcnumber());
            ps.setString(7, news.getNewstype());
            ps.setString(8, String.valueOf(news.getId()));
            n = ps.executeUpdate();
        } catch (SQLException e1) {
            System.out.println(e1);
        } finally {
            DBGet.closeConnection(conn);
        }
        if (n > 0) {
            result = true;
        }
        return result;
    }

    /**
     * 删除新闻
     */
    public boolean deleteById(String id) {
        boolean result = false;
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBGet.getConnection();
            String sql = "DELETE FROM news WHERE id = ?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, id);
            if (ps.executeUpdate() == 1) {
                result = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBGet.closeConnection(conn);
        }
        return result;
    }

    /**
     * 热点新闻
     */
    public ArrayList<News> getHotNews() {
        News news = null;
        ArrayList<News> newsList = new ArrayList<News>();
        Connection conn = null;
        ResultSet rs = null;
        Statement stmt = null;
        try {
            conn = DBGet.getConnection();
            stmt = conn.createStatement();
            String sql = "select * from news order by acnumber desc limit 5";
            rs = stmt.executeQuery(sql);
            while (rs.next()) {
                news = new News();
                news.setId(rs.getInt("id"));
                news.setTitle(rs.getString("title"));
                news.setContent(rs.getString("content"));
                news.setAuthor(rs.getString("author"));
                news.setPubtime(rs.getString("pubtime"));
                news.setKeyword(rs.getString("keyword"));
                news.setAcnumber(rs.getString("acnumber"));
                news.setNewstype(rs.getString("newstype"));
                newsList.add(news);
            }
        } catch (SQLException e1) {
            System.out.println(e1);
        } finally {
            DBGet.closeConnection(conn);
        }
        return newsList;
    }
    /**
     * 按关键字查询新闻
     */
    public ArrayList<News> getNewsByKeyword(String keyword) {
        News news = null;
        ArrayList<News> newsList = new ArrayList<News>();
        Connection conn = null;
        ResultSet rs = null;
        Statement stmt = null;
        PreparedStatement ps = null;
        try {
            conn = DBGet.getConnection();

            String sql = "select * from news where keyword = ?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, keyword);
            rs = ps.executeQuery();
            while (rs.next()) {
                news = new News();
                news.setId(rs.getInt("id"));
                news.setTitle(rs.getString("title"));
                news.setContent(rs.getString("content"));
                news.setAuthor(rs.getString("author"));
                news.setPubtime(rs.getString("pubtime"));
                news.setKeyword(rs.getString("keyword"));
                news.setAcnumber(rs.getString("acnumber"));
                news.setNewstype(rs.getString("newstype"));
                newsList.add(news);
            }
        } catch (SQLException e1) {
            System.out.println(e1);
        } finally {
            DBGet.closeConnection(conn);
        }
        return newsList;
    }
}
